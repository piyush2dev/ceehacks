import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import DateTimePicker from 'react-datetime-picker';
import InstagramLogin from 'react-instagram-login';
import videojs from 'video.js';
import home from './3-1.jpg'
import detail from './4-1.jpg'

import LoadingOverlay from 'react-loading-overlay'
import BounceLoader from 'react-spinners/BounceLoader'
import Example from './Example';

class App extends Component {
  state = {
    imagePath: home,
    isShow:false
  }

  onChange1 = (date)=>{
    console.log(date);
    // console.log(Math.round(date/1000))
    this.setState({
      date1:date
    })
  }

  onChange2 = (date)=>{
    console.log(date);
    this.setState({
      date2:date
    })
    console.log(this.timeUnitsBetween(this.state.date1, date))


    // console.log(Math.round(date/1000))

  }

  timeUnitsBetween= function() {
    // console.log(response);
    // return [
    //   ['days', 24 * 60 * 60],
    //   ['hours', 60 * 60],
    //   ['minutes', 60],
    //   ['seconds', 1]
    // ].reduce((acc, [key, value]) => (acc[key] = Math.floor(delta / value) * isNegative, delta -= acc[key] * isNegative * value, acc), {});
  }

  changeImage = ()=>{
    this.setState(({
      isShow: true
    }))

    setTimeout(()=>{
      this.setState(({
        imagePath: detail,
        isShow: false
      }))
    }, 5000)
   
  }
  
  render() {
    return (
      <Example></Example>
    );
  }
}

export default App;
