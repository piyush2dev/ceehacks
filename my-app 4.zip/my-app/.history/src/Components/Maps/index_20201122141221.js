import main from "../../Assets/main.jpg";
import React from "react";
import { Form, Button } from "react-bootstrap";
import { withRouter } from 'react-router-dom'
import { Map, GoogleApiWrapper } from 'google-maps-react';

class Maps extends React.Component {
  state = {};

  render() {
    return (
      <div style={{ textAlign: "center" }}>
       
      </div>
    );
  }
}

export default withRouter(Maps);
