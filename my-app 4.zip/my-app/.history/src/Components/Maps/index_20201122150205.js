import main from "../../Assets/main.jpg";
import React from "react";
import { Form, Button } from "react-bootstrap";
import { withRouter } from "react-router-dom";
import { Map, GoogleApiWrapper, InfoWindow, Marker } from "google-maps-react";

const mapStyles = {
  width: "100%",
  height: "100%",
};
class MapContainer extends React.Component {
  state = {
    showingInfoWindow: true, // Hides or shows the InfoWindow
    activeMarker: {}, // Shows the active marker upon click
    selectedPlace: {}, // Shows the InfoWindow to the selected place upon a marker
  };

  onMarkerClick1 = (props, marker, e) =>
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true,
      visible1: true,
      visible2: false
    });

  onMarkerClick2 = (props, marker, e) =>
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true,
      visible1: false,
      visible2: true
    });

  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <Map
          google={this.props.google}
          zoom={13}
          style={mapStyles}
          initialCenter={{
            lat: 50.0755,
            lng: 14.3984,
          }}
        >
          <Marker
            icon={{
              url: "https://soprano-voice.s3.amazonaws.com/logo.jpg",
              anchor: new window.google.maps.Point(17, 46),
              scaledSize: new window.google.maps.Size(100, 60),
            }}
            onClick={this.onMarkerClick1}
            name={"Kenyatta International Convention Centre"}
          />
          <InfoWindow
            marker={this.state.activeMarker}
            visible={this.state.visible1}
            onClose={this.onClose}
          >
            <div>
              <span style={{ fontSize: "20px" }}>Distance : 21 KM</span>
              <h5>FOOT CLINIC INDEX - 4</h5>

              <h5 onClick={() => {}}>Foot Clinic</h5>
              <h6>
                MUDr. Petra Vrbová Diabetological outpatient clinic Masaryk
                Municipal Hospital Jilemnice Metyšova 465, 514 01 Jilemnice Tel:
                481 551 145 Email: petra.vrbova@nemjil.cz
              </h6>
              <Button>CONNECT ME WITH CLINIC FOR BOOKING</Button>

              <br></br>

              <Button style={{ marginTop: "10px" }}>
                CLICK HERE FOR TWITTER REVIEWS
              </Button>
            </div>
          </InfoWindow>

          <Marker
            icon={{
              url: "https://soprano-voice.s3.amazonaws.com/logo.jpg",
              anchor: new window.google.maps.Point(17, 46),
              scaledSize: new window.google.maps.Size(100, 60),
            }}
            position={{
              lat: 50.075,
              lng: 14.3384,
            }}
            onClick={this.onMarkerClick2}
            name={"Kenyatta International Convention Centre"}
          />
          <InfoWindow visible={this.state.visible2} onClose={this.onClose}>
            <div>
              <span style={{ fontSize: "20px" }}>Distance : 13 KM</span>
              <h5>FOOT CLINIC INDEX - 2</h5>

              <h5 onClick={() => {}}>Foot Clinic</h5>
              <h6>
                MUDr. Petra Vrbová Diabetological outpatient clinic Masaryk
                Municipal Hospital Jilemnice Metyšova 465, 514 01 Jilemnice Tel:
                481 551 145 Email: petra.vrbova@nemjil.cz
              </h6>
              <Button>CONNECT ME WITH CLINIC FOR BOOKING</Button>

              <br></br>

              <Button style={{ marginTop: "10px" }}>
                CLICK HERE FOR TWITTER REVIEWS
              </Button>
            </div>
          </InfoWindow>

          <Marker
            icon={{
              url: "https://soprano-voice.s3.amazonaws.com/logo.jpg",
              anchor: new window.google.maps.Point(17, 46),
              scaledSize: new window.google.maps.Size(100, 60),
            }}
            position={{
              lat: 50.089,
              lng: 14.4584,
            }}
            onClick={this.onMarkerClick}
            name={"Kenyatta International Convention Centre"}
          />
          <InfoWindow
            marker={this.state.activeMarker}
            visible={true}
            onClose={this.onClose}
          >
            <div>
              <span style={{ fontSize: "20px" }}>Distance : 21 KM</span>
              <h5>FOOT CLINIC INDEX - 4</h5>

              <h5 onClick={() => {}}>Foot Clinic</h5>
              <h6>
                Dr. Pirka Clinic Na Celné 885, 29301 Mladá Boleslav Tel. 326 332
                991 Email: diabetologie@drpirek.cz office hours: Mon 7 am - 12
                noon and 12:30 pm - 3:30 pm
              </h6>
              <Button>CONNECT ME WITH CLINIC FOR BOOKING</Button>

              <br></br>

              <Button style={{ marginTop: "10px" }}>
                CLICK HERE FOR TWITTER REVIEWS
              </Button>
            </div>
          </InfoWindow>

          <Marker
            icon={{
              url: "https://soprano-voice.s3.amazonaws.com/logo.jpg",
              anchor: new window.google.maps.Point(17, 46),
              scaledSize: new window.google.maps.Size(100, 60),
            }}
            position={{
              lat: 50.089,
              lng: 14.5584,
            }}
            onClick={this.onMarkerClick}
            name={"Kenyatta International Convention Centre"}
          />
          <InfoWindow
            marker={this.state.activeMarker}
            visible={true}
            onClose={this.onClose}
          >
            <div>
              <span style={{ fontSize: "20px" }}>Distance : 21 KM</span>
              <h5>FOOT CLINIC INDEX - 4</h5>

              <h5 onClick={() => {}}>Foot Clinic</h5>
              <h6>
                MUDr. Petra Vrbová Diabetological outpatient clinic Masaryk
                Municipal Hospital Jilemnice Metyšova 465, 514 01 Jilemnice Tel:
                481 551 145 Email: petra.vrbova@nemjil.cz
              </h6>
              <Button>CONNECT ME WITH CLINIC FOR BOOKING</Button>

              <br></br>

              <Button style={{ marginTop: "10px" }}>
                CLICK HERE FOR TWITTER REVIEWS
              </Button>
            </div>
          </InfoWindow>
        </Map>
      </div>
    );
  }
}

export default withRouter(
  GoogleApiWrapper({ apiKey: "AIzaSyBv4pPU1wfn70gH-aZKMaDD-wMGDXSRK_U" })(
    MapContainer
  )
);
