import main from "../../Assets/main.jpg";
import React from "react";
import { Form, Button } from "react-bootstrap";
import { withRouter } from "react-router-dom";
import { Map, GoogleApiWrapper,InfoWindow, Marker } from "google-maps-react";

const mapStyles = {
  width: "100%",
  height: "100%",
};
class MapContainer extends React.Component {
  state = {};

  render() {
    return (
      <div style={{ textAlign: "center" }}>
        <Map
          google={this.props.google}
          zoom={14}
          style={mapStyles}
          initialCenter={{
            lat: -1.2884,
            lng: 36.8233,
          }}
        />
      </div>
    );
  }
}

export default withRouter(GoogleApiWrapper({apiKey: 'AIzaSyBv4pPU1wfn70gH-aZKMaDD-wMGDXSRK_U'})(MapContainer));