import main from "./Assets/main.jpg";
import React from "react";

class Home extends React.Component {
  state = {};

  render() {
    return (
      <div style={{ textAlign: "center" }} className="test-demo">
        <img
          src={main}
          width="300"
          style={{ borderRadius: "50%", marginTop: "30px" }}
          className="d-inline-block align-top"
          alt="React Bootstrap logo"
        />
      </div>
    );
  }
}

export default Home;
