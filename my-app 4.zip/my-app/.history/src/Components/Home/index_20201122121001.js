import main from "../../Assets/main.jpg";
import React from "react";
import { Button } from "react-bootstrap";

class Home extends React.Component {
  state = {};

  render() {
    return (
      <div style={{ textAlign: "center" }} className="test-demo">
            <div>
            <img
                src={main}
                width="300"
                style={{ borderRadius: "50%", marginTop: "30px" }}
                className="d-inline-block align-top"
                alt="React Bootstrap logo"
            />
            </div>

            <div style={{marginTop:"60px"}}>
                <span>Running of Secure Server 1</span><br></br>
                <Button variant="primary">I am a <b>Health Proffesional/ Foot Clinic/ General Practitioner</b></Button>{" "}
            </div>

            <div style={{marginTop:"30px"}}>
                <span>Running of Secure Server 2</span> <br></br>
                <Button style={{width:"480px"}} variant="primary">I am a <b>Patient/ User</b></Button>{" "}
            </div>

            <br>
              GDPR COMPLIANT - RUNNING ON SECURE AWS CLOUD SERVER IN VIRTUAL PRIVATE NETWORK
            </br>
      </div>
    );
  }
}

export default Home;
