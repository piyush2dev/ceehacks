import React from "react";
import Header from './Components/Header'
import logo from '../../Assets/logo.jpg'

class App extends React.Component {
  state = {};

  render() {
    return (
      <div className="test-demo">
        <Header></Header>
        <img
              src={logo}
              width="120"
              className="d-inline-block align-top"
              alt="React Bootstrap logo"
            />
      </div>
    );
  }
}

export default App;
