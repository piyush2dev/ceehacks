import React from "react";
import Header from "./Components/Header";
import Home from "./Components/Home";
import Login from "./Components/Login";
import Clinics from "./Components/Clinics"
import Details from "./Components/Clinics"


import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

class App extends React.Component {
  state = {};

  render() {
    return (
      <div>
        <Header></Header>
        <Router>
          <div>
            {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
            <Switch>
              <Route path="/login">
                <Login></Login>
              </Route>

              <Route path="/clinics">
                <Clinics></Clinics>
              </Route>

              <Route path="/footclinic">
                
              </Route>

              <Route path="/">
                <Home></Home>
              </Route>
            </Switch>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;
