import React from "react";
import Header from './Components/Header'

class App extends React.Component {
  state = {};

  render() {
    return (
      <div>
        <Header>
      </div>
    );
  }
}

export default App
