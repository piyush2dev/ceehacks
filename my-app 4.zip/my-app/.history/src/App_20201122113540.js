import React from "react";
import Header from './Components/Header'
import main from './Assets/main.jpg'

class App extends React.Component {
  state = {};

  render() {
    return (
      <div  style={{textAlign:"center"}} className="test-demo">
        <Header></Header>
        <img
              src={main}
              width="300"
              style={{borderRadius:"50%", textAlign:"center"}}
              className="d-inline-block align-top"
              alt="React Bootstrap logo"
            />
      </div>
    );
  }
}

export default App;
