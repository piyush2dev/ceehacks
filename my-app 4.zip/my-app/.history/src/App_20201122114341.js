import React from "react";
import Header from "./Components/Header";
import Home from "./Components/Home";

import main from "./Assets/main.jpg";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

class App extends React.Component {
  state = {};

  render() {
    return (
      <div style={{ textAlign: "center" }} className="test-demo">
        <Header></Header>
        <Router>
          <div>
            {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
            <Switch>
              <Route path="/about">
                
              </Route>
              <Route path="/users">
                
              </Route>
              <Route path="/">
                <Home></Home>
              </Route>
            </Switch>
          </div>
        </Router>
        <img
          src={main}
          width="300"
          style={{ borderRadius: "50%", marginTop: "30px" }}
          className="d-inline-block align-top"
          alt="React Bootstrap logo"
        />
      </div>
    );
  }
}

export default App;
