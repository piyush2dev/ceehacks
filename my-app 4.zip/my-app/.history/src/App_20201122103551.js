import React from 'react'
import 'bootstrap/dist/css/bootstrap.css';

class App extends React.Component {
    state = {
    
    }

    render () {
      return <div className="test-demo">
        <span>assa</span>  
      </div>
    }
}

 
export default App