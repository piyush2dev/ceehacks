import { ReactMic } from 'react-mic';
import React, { Component } from 'react';

 
export class Example extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      record: false
    }
  }

  componentDidMount = ()=>{
    var ws = new WebSocket("ws://34.73.147.151:8888");
    this.ws=ws;
    ws.onopen = () => {
        console.log("connected websocket main component");
    };

    ws.onmessage = evt => { 
        console.log(evt.data);
    };

  }
 
  startRecording = () => {
    this.setState({ record: true });
  }
 
  stopRecording = () => {
    this.setState({ record: false });
  }
 
  onData=(recordedBlob) =>{
    console.log('chunk of real-time data is: ', recordedBlob);
    // this.ws.send(recordedBlob);


  }
 
  onStop=(recordedBlob) =>{
    console.log('recordedBlob is: ', recordedBlob);
    var reader = new FileReader();
    window.tt = recordedBlob;

    // get arrayBuffer from blob
        let fileReader = new FileReader();

        fileReader.readAsArrayBuffer(recordedBlob.blob);

        fileReader.onload = function(event) {
            let arrayBuffer = fileReader.result;
            console.log(arrayBuffer);
        };

        let reader = new FileReader();
    reader.readAsDataURL(recordedBlob.blob);

  }
 
  render() {
    return (
      <div>
        <ReactMic
          record={this.state.record}
          className="sound-wave"
          onStop={this.onStop}
          onData={this.onData}
          strokeColor="#000000"
          backgroundColor="#FF4081" />
        <button onClick={this.startRecording} type="button">Start</button>
        <button onClick={this.stopRecording} type="button">Stop</button>
      </div>
    );
  }
}

export default Example;
