import React from "react";
import { Form, Button, Container, Row, Col, Card } from "react-bootstrap";
import { withRouter } from "react-router-dom";
import foot1 from "../../Assets/foot1.jpg";
import foot2 from "../../Assets/foot2.jpeg";
import foot3 from "../../Assets/foot3.jpeg";

class Clinics extends React.Component {
  state = {};

  render() {
    return (
      <div style={{ marginTop: "20px" }}>
        <Container>
          <span style={{fontSize:"20px"}}>
              <b>Select Foot Clinic/ Health Proffesional You Need to Connect to :</b>
          </span>
          {/* Stack the columns on mobile by making one full-width and the other half-width */}
          <Row style={{marginTop:"30px"}}>
            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
                Distance : 28 Km
                <div>
                  Surgery hours:
                  <div>Mon - Thu 7 - 15:30</div>
                </div>

                <Card.Img variant="top" src={foot1} />
                <Card.Body>
                  <Card.Title>Brno FN u sv.Anny
                      
                     </Card.Title>
                  <Card.Text>
                    MUDr. Jana Pecová
                    FN u sv. Anny, diabetological and educational center, II.
                    internal clinic Pekařská 53, Brno, 656 91 tel: 543 18 2271,
                    2266 Email: jana.pecova@fnusa.cz
                  </Card.Text>
                  <Button onClick={()=>{
                       this.props.history.push('/details')
                  }} variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>

            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
                Distance : 36 Km
                <div>
                  Surgery hours:
                  <div>Mon 9 am - 11 pm</div>
                </div>
                <Card.Img variant="top" src={foot2} />
                <Card.Body>
                  <Card.Title>Břeclav</Card.Title>
                  <Card.Text>

                    MUDr. Radoslava Novotná
                    Nemocnice Břeclav, surgical department U Nemocnice 1, 69074
                    Břeclav Tel: 519 315 534 Email: novotna radoslava@seznam.cz

                    other doctors: MUDr.Buchtela, MUDr.M.Pikna - surgeon
                    other doctors: MUDr.Buchtela, MUDr.M.Pikna - surgeon
                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>

            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
              Distance : 41 Km
                <div>
                  Surgery hours:
                  <div>Mon 15:45 - 18:30</div>
                  <div></div>
                </div>
                <Card.Img variant="top" src={foot3} />
                <Card.Body>
                  <Card.Title>České Budějovice Medipont</Card.Title>
                  <Card.Text>
                  MUDr. Ondřej Vrtal
                    Another doctor: MUDr. Ivo Staněk Diabetology Center at the Internal Medicine Department České 
                    Budějovice Hospital  B. Němcové 54, České Budějovice, 370 87  tel: 387 875 479 email: vrtal.ondrej@nemcb.cz 

                    Tel: 519 315 531

                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>


          <Row style={{marginTop:"30px"}}>
            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
                Distance :  Km
                <div>
                  Surgery hours:
                  <div>Mon 8 am - 12 noon</div>
                  <div>Thu 8 am - 12 pm</div>
                </div>

                <Card.Img variant="top" src={foot1} />
                <Card.Body>
                  <Card.Title>Brno FN u sv.Anny
                      
                     </Card.Title>
                  <Card.Text>
                    MUDr. Jana Pecová
                    FN u sv. Anny, diabetological and educational center, II.
                    internal clinic Pekařská 53, Brno, 656 91 tel: 543 18 2271,
                    2266 Email: jana.pecova@fnusa.cz
                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>

            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
                Distance : 18 Km
                <div>
                  Surgery hours:
                  <div>Mon 9 am - 11 noon</div>
                  <div>Thu 7 am - 11 pm</div>
                </div>
                <Card.Img variant="top" src={foot2} />
                <Card.Body>
                  <Card.Title>Břeclav</Card.Title>
                  <Card.Text>

                    MUDr. Radoslava Novotná
                    Nemocnice Břeclav, surgical department U Nemocnice 1, 69074
                    Břeclav Tel: 519 315 534 Email: novotna radoslava@seznam.cz

                    other doctors: MUDr.Buchtela, MUDr.M.Pikna - surgeon
                    other doctors: MUDr.Buchtela, MUDr.M.Pikna - surgeon
                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>

            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
              Distance : 18 Km
                <div>
                  Surgery hours:
                  <div>Mon 9 am - 11 noon</div>
                  <div>Thu 7 am - 11 pm</div>
                </div>
                <Card.Img variant="top" src={foot3} />
                <Card.Body>
                  <Card.Title>České Budějovice Medipont</Card.Title>
                  <Card.Text>
                  MUDr. Ondřej Vrtal
                    Another doctor: MUDr. Ivo Staněk Diabetology Center at the Internal Medicine Department České 
                    Budějovice Hospital  B. Němcové 54, České Budějovice, 370 87  tel: 387 875 479 email: vrtal.ondrej@nemcb.cz 

                    Tel: 519 315 531

                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          <Row style={{marginTop:"30px"}}>

            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
                Distance : 18 Km
                <div>
                  Surgery hours:
                  <div>Mon 8 am - 12 noon</div>
                  <div>Thu 8 am - 12 pm</div>
                </div>

                <Card.Img variant="top" src={foot1} />
                <Card.Body>
                  <Card.Title>Brno FN u sv.Anny
                      
                     </Card.Title>
                  <Card.Text>
                    MUDr. Jana Pecová
                    FN u sv. Anny, diabetological and educational center, II.
                    internal clinic Pekařská 53, Brno, 656 91 tel: 543 18 2271,
                    2266 Email: jana.pecova@fnusa.cz
                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>

            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
                Distance : 18 Km
                <div>
                  Surgery hours:
                  <div>Mon 9 am - 11 noon</div>
                  <div>Thu 7 am - 11 pm</div>
                </div>
                <Card.Img variant="top" src={foot2} />
                <Card.Body>
                  <Card.Title>Břeclav</Card.Title>
                  <Card.Text>

                    MUDr. Radoslava Novotná
                    Nemocnice Břeclav, surgical department U Nemocnice 1, 69074
                    Břeclav Tel: 519 315 534 Email: novotna radoslava@seznam.cz

                    other doctors: MUDr.Buchtela, MUDr.M.Pikna - surgeon
                    other doctors: MUDr.Buchtela, MUDr.M.Pikna - surgeon
                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>

            <Col xs={6} md={4}>
              <Card style={{ width: "18rem" }}>
              Distance : 18 Km
                <div>
                  Surgery hours:
                  <div>Mon 9 am - 11 noon</div>
                  <div>Thu 7 am - 11 pm</div>
                </div>
                <Card.Img variant="top" src={foot3} />
                <Card.Body>
                  <Card.Title>České Budějovice Medipont</Card.Title>
                  <Card.Text>
                  MUDr. Ondřej Vrtal
                    Another doctor: MUDr. Ivo Staněk Diabetology Center at the Internal Medicine Department České 
                    Budějovice Hospital  B. Němcové 54, České Budějovice, 370 87  tel: 387 875 479 email: vrtal.ondrej@nemcb.cz 

                    Tel: 519 315 531

                  </Card.Text>
                  <Button variant="primary">Connect with Clinic</Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          
        </Container>
      </div>
    );
  }
}

export default withRouter(Clinics);
