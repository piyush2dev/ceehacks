import React from "react";
import { Navbar } from "react-bootstrap";
import logo from "../../Assets/logo.jpg";

class VideoCon extends React.Component {
  state = {};

  render() {
    return (
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:"20px"}}>VIDEO CONFERENCING STARTED: </div>
        <div style={{marginTop:"20px"}}>
          <div>Video Room 1</div>
          <video width="620" height="340" controls>
            <source src="https://soprano-voice.s3.amazonaws.com/videoplayback.mp4" type="video/mp4"></source>
          </video>

          <div>Video Room 2</div>
          <video width="200" height="340" controls>
            <source src="https://soprano-voice.s3.amazonaws.com/foot-video.mp4" type="video/mp4"></source>
          </video>


        </div>
      </div>
    );
  }
}

export default VideoCon;
