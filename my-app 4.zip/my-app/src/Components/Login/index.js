import main from "../../Assets/main.jpg";
import React from "react";
import { Form, Button } from "react-bootstrap";
import { withRouter } from 'react-router-dom'

class Login extends React.Component {
  state = {};

  render() {
    return (
      <div style={{ textAlign: "center" }} className="test-demo">
        <img
          src={main}
          width="200"
          style={{ borderRadius: "50%", marginTop: "30px" }}
          className="d-inline-block align-top"
          alt="React Bootstrap logo"
        />

        <Form style={{maxWidth:"300px", margin:"auto", marginTop:"50px"}}>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Enter Your Health Care ID</Form.Label>
            <Form.Control value="prague@footclinic1.com" type="email" placeholder="Enter email" />
            <Form.Text className="text-muted">
              We'll never share your ID with anyone else.
            </Form.Text>
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label>Enter Your Health Care Password</Form.Label>
            <Form.Control type="password" placeholder="Password" />
          </Form.Group>
          <Form.Group controlId="formBasicCheckbox">
            <Form.Check type="checkbox" label="Secure Log In" />
          </Form.Group>
          <Button onClick={()=>{
               this.props.history.push('/clinics')
          }} variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </div>
    );
  }
}

export default withRouter(Login);
