import React from "react";
import { Navbar } from "react-bootstrap";
import logo from "../../Assets/logo.jpg";
import { Form, Button } from "react-bootstrap";
import { withRouter } from "react-router-dom";

class Patient extends React.Component {
  state = {};

  render() {
    return (
      <div>
        <div style={{margin:"auto", maxWidth:"400px", fontSize:"20px"}}>
            Securely Connected Patitent to Foot Clinic
        </div>

        <Form style={{ maxWidth: "600px", margin: "auto", marginTop: "20px" }}>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Patient Name</Form.Label>
            <Form.Control
              value="Piyush Aggarwal"
              placeholder="Enter email"
            />
            <Form.Text className="text-muted">
            
            </Form.Text>
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label>Patient Contact</Form.Label>
            <Form.Control value="+512712912212" type="text" placeholder="Password" />
          </Form.Group>

          <Form.Group>
            <Form.File id="exampleFormControlFile1" label="Patient PhotoGraph" />
          </Form.Group>


          <Form.Group controlId="formBasicRange">
                <Form.Label>TIME SLOT BOOKING (8 a.m - 9 p.m)</Form.Label>
                <Form.Control type="range" />
          </Form.Group>
    
          
          <Form.Group controlId="formBasicPassword">
            <Form.Label>Patient X RAY LINK</Form.Label>
            <Form.Control value="https://drive.google.com/file/d/1I9iJRf19oTRKX9_z0BkFTFqq9VSaSf77/view?usp=sharing" type="text" placeholder="Password" />
          </Form.Group>

              
          <div>
          <video width="320" height="240" controls>
            <source src="" type="video/mp4"></source>
          </video>
          </div>

          <Form.Group>
            <Form.File id="exampleFormControlFile1" label="Click to Add Voice Note" />
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label>Patient CT LINK</Form.Label>
            <Form.Control value="https://drive.google.com/file/d/1I9iJRf19oTRKX9_z0BkFTFqq9VSaSf77/view?usp=sharing" type="text" placeholder="Password" />
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label>Patient MR LINK</Form.Label>
            <Form.Control value="https://drive.google.com/file/d/1I9iJRf19oTRKX9_z0BkFTFqq9VSaSf77/view?usp=sharing" type="text" placeholder="Password" />
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label>Patient MR LINK</Form.Label>
            <Form.Control value="https://drive.google.com/file/d/1I9iJRf19oTRKX9_z0BkFTFqq9VSaSf77/view?usp=sharing" type="text" placeholder="Password" />
          </Form.Group>


          <Button  variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </div>
    );
  }
}

export default withRouter(Patient);
