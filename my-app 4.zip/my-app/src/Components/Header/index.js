import React from "react";
import { Navbar } from "react-bootstrap";
import logo from '../../Assets/logo.jpg'

class Header extends React.Component {
  state = {};

  render() {
    return (
      <div style={{background:"red"}}>
        <Navbar bg="dark">
          <Navbar.Brand href="#home">
            <img
              src={logo}
              onClick={()=>{
                window.location.replace(window.location.origin
                    )
              }}
              width="100"
              className="d-inline-block align-top"
              alt="React Bootstrap logo"
            />
          </Navbar.Brand>
           
           <span style={{color:"#FFF", fontSize:"20px"}}>Foot Clinic Network Platform (GDPR COMPLIANT)</span>
        </Navbar>       
      </div>
    );
  }
}

export default Header;
