import React from "react";
import Header from "./Components/Header";
import Home from "./Components/Home";
import Login from "./Components/Login";
import Clinics from "./Components/Clinics"
import Details from "./Components/Details"
import VideoCon from "./Components/VideoCon"
import MapContainer from "./Components/Maps"
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Patient from "./Components/Patient"
class App extends React.Component {
  state = {};

  render() {
    return (
      <div>
        <Header></Header>
        <Router>
          <div>
            {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
            <Switch>
              <Route path="/login">
                <Login></Login>
              </Route>

              <Route path="/maps">
                <MapContainer></MapContainer>
              </Route>


              <Route path="/clinics">
                <Clinics></Clinics>
              </Route>

              <Route path="/details">
                <Details></Details>
              </Route>

              <Route path="/video">
                <VideoCon></VideoCon>
              </Route>

              <Route path="/patient">
                <Patient></Patient>
              </Route>

              <Route path="/">
                <Home></Home>
              </Route>

         

            
            </Switch>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;
